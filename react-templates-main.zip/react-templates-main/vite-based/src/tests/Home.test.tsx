import { render, screen } from '@testing-library/react';

import Home from '../pages/Home';

describe('Home', () => {
  it('renders headline', () => {
    render(<Home />);

    expect(screen.queryByText('Home')).toBeInTheDocument();
  });
});
