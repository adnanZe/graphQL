# Vite React template

A starter react template created using [Vite](https://vitejs.dev/)

## Libraries already included

1. [Axios](https://axios-http.com/docs/intro) (data fetching)
2. [React router](https://reactrouter.com/en/main) (client-side routing)
3. [TanStack Query](https://tanstack.com/query/latest/docs/react/overview) (data fetching)
4. [Vitest](https://vitest.dev/) (unit testing)

## Setup the project

1. Clone the repository: https://gitlab.stefanini.com/adm-frontend/react-templates.git

2. Copy the folder vite-based to a new location

3. Open the folder and run: **npm ci**
   to install the dependencies of the application

> **_NOTE:_** The project can be run in a docker container
