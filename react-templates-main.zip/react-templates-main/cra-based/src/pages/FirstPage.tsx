import React from 'react';

export default function FirstPage() {
  return <h1>FirstPage</h1>;
}
